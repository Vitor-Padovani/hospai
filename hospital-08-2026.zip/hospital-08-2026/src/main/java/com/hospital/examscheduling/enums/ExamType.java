package com.hospital.examscheduling.enums;

public enum ExamType {
    LABORATORIAL,
    IMAGEM,
    RAIO_X,
    ULTRASSONOGRAFIA,
    ELETROCARDIOGRAMA,
    ESPIROMETRIA,
    ENDOSCOPIA,
    CISTOSCOPIA,
    PREDISPOSICAO_GENETICA,
    PAINEIS_GENETICOS
}
